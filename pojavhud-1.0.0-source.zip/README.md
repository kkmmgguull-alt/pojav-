# PojavHUD – Fabric 1.21.1

Customizable Minecraft item texture overlay for hotbar slots 1–9.  
Designed for PojavLauncher users who want Minecraft item icons over their custom touchscreen buttons.

**This mod does NOT interact with PojavLauncher buttons in any way.**  
It only draws pure visual item icons that you can position yourself.

## Features
- 9 icons that automatically show the items currently in hotbar slots 1–9
- Empty slots hide their icon
- Fully movable, resizable and opacity-adjustable
- Positions saved to `config/pojavhud.json`
- Keybinds: **N** = toggle visibility, **O** = open editor
- Mod Menu support

## Build (required – produces the .jar)

You need **Java 21**.

```bash
# On Linux / macOS
chmod +x gradlew
./gradlew build

# On Windows
gradlew.bat build
```

The finished mod will be at:

```
build/libs/pojavhud-1.0.0.jar
```

Copy that single file into your PojavLauncher `mods` folder together with Fabric API.

## Usage
1. Start the game
2. Press **O** to open the editor
3. Drag each of the 9 icons over your existing PojavLauncher touch buttons
4. Use the bottom-right white handle to resize
5. Scroll wheel to change opacity
6. Click **Save & Close**

The icons will now sit on top of your buttons and update live when the items in your hotbar change.
